import json
import random
import sys
import os
import time
import threading
import webbrowser
import re
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk


class SteamRandomizerGUI:
    """
    Steam library randomizer with persistent metadata caching.

    Important changes from the original:
    - Fetches Store metadata in batches instead of one request per game.
    - Retries 429/5xx/network failures with backoff.
    - Never permanently marks a game as failed because of a temporary error.
    - Caches every owned app, including games for which Steam returns no genres.
    - Rebuilds the genre list from the cache after metadata is loaded.
    - Saves the cache atomically so an interrupted run is less likely to corrupt it.
    - Keeps Tkinter UI updates on the main thread.
    """

    MAX_WORKERS = 3
    REQUEST_TIMEOUT = 20
    MAX_RETRIES = 5

    def __init__(self, root):
        self.root = root
        self.root.title("Steam Weighted Randomizer")
        self.root.geometry("550x750")

        # Use the supplied question-mark image as the application icon.
        self.app_icon = None
        icon_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "icon.png"
        )
        if os.path.exists(icon_path):
            try:
                self.app_icon = tk.PhotoImage(file=icon_path)
                self.root.iconphoto(True, self.app_icon)
            except Exception as e:
                print(f"Could not load application icon: {e}")

        self.config = self.load_config()
        self.cache_file = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "game_cache.json"
        )

        self.game_cache = self.load_cache()
        self.settings_file = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "randomizer_settings.json"
        )
        self.settings = self.load_settings()
        self.blacklist = set(str(x) for x in self.settings.get("blacklist", []))
        self.only_installed = bool(self.settings.get("only_installed", True))
        self.include_family_shared = bool(
            self.settings.get("include_family_shared", True)
        )
        self.owned_games = []
        self.all_genres = set()
        self.cache_lock = threading.Lock()

        self.setup_ui()

        threading.Thread(target=self.initialize_data, daemon=True).start()

    # ----------------------------
    # Cache
    # ----------------------------

    def load_config(self):
        config_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "config.json"
        )
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            messagebox.showerror(
                "Config Error", f"Could not load config.json:\n{e}"
            )
            sys.exit(1)

    def load_cache(self):
        if not os.path.exists(self.cache_file):
            return {}

        try:
            with open(self.cache_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            if not isinstance(data, dict):
                return {}

            # Normalise old cache entries so the new code can use them.
            for appid, entry in data.items():
                if not isinstance(entry, dict):
                    data[appid] = {}
                    entry = data[appid]

                entry.setdefault("name", f"Unknown ({appid})")
                entry.setdefault("genres", None)
                entry.setdefault("icon_url", None)
                entry.setdefault("installed", False)
                entry.setdefault("family_shared", False)
                entry.setdefault("fetched", False)

            return data

        except Exception as e:
            print(f"Error loading cache: {e}")
            return {}

    def load_settings(self):
        if not os.path.exists(self.settings_file):
            return {
                "blacklist": [],
                "only_installed": True,
                "include_family_shared": True,
            }
        try:
            with open(self.settings_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                data = {}
            data.setdefault("blacklist", [])
            data.setdefault("only_installed", True)
            data.setdefault("include_family_shared", True)
            return data
        except Exception as e:
            print(f"Error loading settings: {e}")
            return {
                "blacklist": [],
                "only_installed": True,
                "include_family_shared": True,
            }

    def save_settings(self):
        try:
            tmp_file = self.settings_file + ".tmp"
            with open(tmp_file, "w", encoding="utf-8") as f:
                json.dump({
                    "blacklist": sorted(self.blacklist),
                    "only_installed": self.only_installed,
                    "include_family_shared": self.include_family_shared,
                }, f, indent=2, ensure_ascii=False)
            os.replace(tmp_file, self.settings_file)
        except Exception as e:
            print(f"Error saving settings: {e}")

    def get_steam_library_paths(self):
        """Find Steam library folders on Windows."""
        paths = set()
        candidates = [
            os.path.expandvars(r"%ProgramFiles(x86)%\Steam"),
            os.path.expandvars(r"%ProgramFiles%\Steam"),
            os.path.expandvars(r"%LOCALAPPDATA%\Steam"),
        ]

        try:
            import winreg
            registry_locations = [
                (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam"),
            ]
            for hive, key_path in registry_locations:
                try:
                    with winreg.OpenKey(hive, key_path) as key:
                        install_path, _ = winreg.QueryValueEx(key, "InstallPath")
                        if install_path:
                            candidates.append(install_path)
                except OSError:
                    pass
        except ImportError:
            pass

        for steam_path in candidates:
            if not steam_path or not os.path.isdir(steam_path):
                continue
            steam_path = os.path.normpath(steam_path)
            paths.add(steam_path)
            vdf = os.path.join(steam_path, "steamapps", "libraryfolders.vdf")
            if os.path.exists(vdf):
                try:
                    with open(vdf, "r", encoding="utf-8", errors="ignore") as f:
                        text = f.read()
                    for match in re.finditer(r'"path"\s+"([^"]+)"', text, re.IGNORECASE):
                        library = match.group(1).replace(chr(92) + chr(92), chr(92))
                        if os.path.isdir(library):
                            paths.add(os.path.normpath(library))
                except OSError:
                    pass
        return paths

    def get_installed_apps(self):
        """Read Steam appmanifest files, including Family Shared installs."""
        apps = {}
        for library in self.get_steam_library_paths():
            steamapps = os.path.join(library, "steamapps")
            if not os.path.isdir(steamapps):
                continue
            try:
                for filename in os.listdir(steamapps):
                    match = re.fullmatch(r"appmanifest_(\d+)\.acf", filename, re.IGNORECASE)
                    if not match:
                        continue
                    appid = match.group(1)
                    path = os.path.join(steamapps, filename)
                    try:
                        with open(path, "r", encoding="utf-8", errors="ignore") as f:
                            text = f.read()
                        name_match = re.search(r'"name"\s+"([^"]*)"', text)
                        state_match = re.search(r'"StateFlags"\s+"(\d+)"', text)
                        name = name_match.group(1) if name_match else f"Steam App {appid}"
                        state = int(state_match.group(1)) if state_match else 4
                        # StateFlags 4 = fully installed. Other states can be
                        # updating/downloading, so do not launch them.
                        if state & 4:
                            apps[appid] = {"name": name, "installed": True}
                    except OSError:
                        pass
            except OSError:
                pass
        return apps

    def save_cache(self):
        """Atomically replace the cache file."""
        with self.cache_lock:
            data = dict(self.game_cache)

            tmp_file = self.cache_file + ".tmp"
            try:
                with open(tmp_file, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)

                os.replace(tmp_file, self.cache_file)
            except Exception as e:
                print(f"Error saving cache: {e}")
                try:
                    if os.path.exists(tmp_file):
                        os.remove(tmp_file)
                except OSError:
                    pass

    # ----------------------------
    # UI
    # ----------------------------

    def setup_ui(self):
        style = ttk.Style()
        style.configure("TLabel", font=("Segoe UI", 10))
        style.configure("Header.TLabel", font=("Segoe UI", 16, "bold"))

        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(expand=True, fill="both")

        self.header = ttk.Label(
            main_frame,
            text="Steam Game Randomizer",
            style="Header.TLabel",
        )
        self.header.pack(pady=(0, 20))

        self.genre_frame = ttk.LabelFrame(
            main_frame,
            text="Filter by Genre (Hold Ctrl to multi-select)",
        )
        self.genre_frame.pack(
            pady=10, padx=0, fill="both", expand=True
        )

        self.genre_listbox = tk.Listbox(
            self.genre_frame,
            selectmode="multiple",
            height=8,
            font=("Segoe UI", 10),
            highlightthickness=1,
        )
        self.genre_listbox.pack(
            padx=10, pady=10, fill="both", expand=True
        )

        options_frame = ttk.Frame(main_frame)
        options_frame.pack(fill="x", pady=(0, 8))

        self.installed_var = tk.BooleanVar(value=self.only_installed)
        ttk.Checkbutton(
            options_frame, text="Only pick installed games",
            variable=self.installed_var, command=self.toggle_installed_only
        ).pack(side="left")

        self.shared_var = tk.BooleanVar(value=self.include_family_shared)
        ttk.Checkbutton(
            options_frame, text="Include Steam Family shared games",
            variable=self.shared_var, command=self.toggle_family_shared
        ).pack(side="left", padx=(12, 0))

        ttk.Button(
            options_frame, text="Manage Blacklist", command=self.open_blacklist
        ).pack(side="right")

        self.display_frame = ttk.Frame(main_frame)
        self.display_frame.pack(pady=20, fill="both")

        self.icon_label = ttk.Label(self.display_frame, text="🎮")
        self.icon_label.pack()

        self.name_label = ttk.Label(
            self.display_frame,
            text="Ready to pick!",
            font=("Segoe UI", 14, "bold"),
            wraplength=450,
            justify="center",
        )
        self.name_label.pack(pady=10)

        self.stats_label = ttk.Label(self.display_frame, text="")
        self.stats_label.pack()

        self.progress = ttk.Progressbar(
            main_frame,
            orient="horizontal",
            length=400,
            mode="determinate",
        )
        self.progress.pack(pady=10)

        self.random_btn = ttk.Button(
            main_frame,
            text="Pick a Game!",
            command=self.pick_game,
            state="disabled",
        )
        self.random_btn.pack(pady=20)

        self.status_var = tk.StringVar(value="Initializing...")
        self.status_label = ttk.Label(
            main_frame,
            textvariable=self.status_var,
            font=("Segoe UI", 9),
            foreground="gray",
        )
        self.status_label.pack(side="bottom", pady=10)

    def set_status(self, text):
        self.root.after(0, lambda: self.status_var.set(text))

    def update_progress(self, current, total):
        def update():
            self.progress["maximum"] = max(total, 1)
            self.progress["value"] = current
            self.status_var.set(
                f"Updating game details... {current}/{total}"
            )

        self.root.after(0, update)

    def update_genre_list(self):
        def update():
            current_selection = {
                self.genre_listbox.get(i)
                for i in self.genre_listbox.curselection()
            }

            self.genre_listbox.delete(0, tk.END)

            for genre in sorted(self.all_genres, key=str.casefold):
                self.genre_listbox.insert(tk.END, genre)

            for i in range(self.genre_listbox.size()):
                if self.genre_listbox.get(i) in current_selection:
                    self.genre_listbox.selection_set(i)

        self.root.after(0, update)

    # ----------------------------
    # Initialisation
    # ----------------------------

    def initialize_data(self):
        try:
            self.set_status("Fetching your library...")
            games = self.get_steam_games()

            # Steam's public GetOwnedGames API only returns games owned by the
            # account. Steam Families shared licenses are not included there.
            # We therefore also inspect local Steam appmanifest files. Any
            # installed Steam game that is not in GetOwnedGames is treated as a
            # Family Shared candidate. This works without asking for a Steam
            # password or access token.
            installed_apps = self.get_installed_apps()
            owned_ids = {str(g["appid"]) for g in games}

            if self.include_family_shared:
                for appid, local in installed_apps.items():
                    if appid not in owned_ids:
                        games.append({
                            "appid": int(appid),
                            "name": local["name"],
                            "playtime_forever": 0,
                            "family_shared": True,
                        })

            self.owned_games = games

            # Make sure every game has a cache entry immediately.
            for game in games:
                appid = str(game["appid"])
                old = self.game_cache.get(appid, {})
                self.game_cache[appid] = {
                    "name": game.get("name", old.get("name", f"Unknown ({appid})")),
                    "genres": old.get("genres"),
                    "icon_url": old.get("icon_url"),
                    "installed": bool(installed_apps.get(appid, {}).get("installed", False)),
                    "family_shared": bool(game.get("family_shared", old.get("family_shared", False))),
                    "fetched": bool(old.get("fetched", False)),
                }

            self.save_cache()

            # Load all genres that are already cached.
            self.rebuild_genres_from_cache()

            # Only fetch apps whose Store metadata has not successfully
            # been cached yet.
            to_fetch = [
                str(game["appid"])
                for game in games
                if not self.game_cache[str(game["appid"])].get("fetched", False)
            ]

            if to_fetch:
                self.set_status(
                    f"Loading Steam metadata for {len(to_fetch)} games..."
                )
                self.fetch_all_metadata(to_fetch)
            else:
                self.set_status("All game metadata loaded from cache.")

            # Rebuild one final time after all metadata has arrived.
            self.rebuild_genres_from_cache()

            self.save_cache()

            self.root.after(0, self.finish_initialization, len(games))

        except Exception as e:
            print(f"Initialization error: {e}")
            self.root.after(
                0,
                lambda: messagebox.showerror(
                    "Error",
                    f"Failed to initialize:\n{e}",
                ),
            )
            self.set_status(f"Error: {e}")

    def finish_initialization(self, game_count):
        self.progress["value"] = 0
        self.random_btn.config(state="normal")
        shared_count = sum(1 for g in self.owned_games if self.game_cache.get(str(g["appid"]), {}).get("family_shared"))
        self.status_var.set(
            f"Library Ready: {game_count} games ({shared_count} Family Shared) | "
            f"{len(self.all_genres)} genres"
        )

    def rebuild_genres_from_cache(self):
        genres = set()

        for data in self.game_cache.values():
            cached_genres = data.get("genres")
            if isinstance(cached_genres, list):
                genres.update(
                    str(g).strip()
                    for g in cached_genres
                    if str(g).strip()
                )

        self.all_genres = genres
        self.update_genre_list()

    # ----------------------------
    # Steam API
    # ----------------------------

    def get_steam_games(self):
        # HTTPS avoids unnecessary HTTP redirects.
        url = (
            "https://api.steampowered.com/"
            "IPlayerService/GetOwnedGames/v0001/"
        )

        params = {
            "key": self.config["api_key"],
            "steamid": self.config["steam_id"],
            "format": "json",
            "include_appinfo": "1",
            "include_played_free_games": "1",
        }

        response = requests.get(
            url,
            params=params,
            timeout=self.REQUEST_TIMEOUT,
        )
        response.raise_for_status()

        data = response.json()
        response_data = data.get("response", {})

        if "games" not in response_data:
            raise Exception(
                "Could not find games. Check that your Steam profile "
                "and game details are Public."
            )

        return response_data["games"]

    def fetch_all_metadata(self, appids):
        """
        Steam's appdetails endpoint does NOT reliably accept a comma-separated
        list of app IDs.  The previous version tried batching them into one
        request, which is why Steam returned HTTP 400 for every batch.

        We therefore request one app at a time, but use a small thread pool and
        retry/backoff so a large library is still practical.
        """
        total = len(appids)
        completed = 0

        with ThreadPoolExecutor(max_workers=self.MAX_WORKERS) as executor:
            future_to_appid = {
                executor.submit(self.fetch_one_game, appid): appid
                for appid in appids
            }

            for future in as_completed(future_to_appid):
                appid = future_to_appid[future]

                try:
                    result = future.result()

                    if result is not None:
                        self.apply_batch_result({appid: result})

                except Exception as e:
                    # Temporary errors are deliberately NOT marked as fetched.
                    # They will be retried next time the program starts.
                    print(f"Game {appid} failed: {e}")

                completed += 1
                self.update_progress(completed, total)

                # Persist progress regularly. If Steam starts rate limiting,
                # everything already completed remains cached.
                if completed % 10 == 0:
                    self.save_cache()

        self.save_cache()

    def fetch_one_game(self, appid):
        """Fetch metadata for exactly one Steam app."""
        url = "https://store.steampowered.com/api/appdetails"
        params = {
            "appids": str(appid),
            "l": "english",
            "cc": "gb",
        }

        last_error = None

        for attempt in range(self.MAX_RETRIES):
            try:
                response = requests.get(
                    url,
                    params=params,
                    timeout=self.REQUEST_TIMEOUT,
                )

                if response.status_code == 429:
                    wait = min(60, 5 * (2 ** attempt))
                    print(
                        f"Rate limited on {appid}. "
                        f"Waiting {wait}s before retry..."
                    )
                    time.sleep(wait)
                    continue

                if response.status_code in (500, 502, 503, 504):
                    wait = min(30, 2 ** attempt)
                    print(
                        f"Steam returned HTTP {response.status_code} "
                        f"for {appid}. Retrying in {wait}s..."
                    )
                    time.sleep(wait)
                    continue

                response.raise_for_status()
                data = response.json()

                entry = data.get(str(appid))

                if not isinstance(entry, dict):
                    raise RuntimeError(
                        f"Steam returned no metadata for app {appid}"
                    )

                # Steam can legitimately return success=False for apps that
                # have no public Store page. That is a completed lookup, not
                # a temporary network failure.
                if not entry.get("success"):
                    return None

                return entry.get("data", {})

            except (requests.RequestException, ValueError) as e:
                last_error = e
                wait = min(30, 2 ** attempt)

                print(
                    f"Metadata request for {appid} failed "
                    f"(attempt {attempt + 1}/{self.MAX_RETRIES}): {e}"
                )

                if attempt < self.MAX_RETRIES - 1:
                    time.sleep(wait)

        raise RuntimeError(
            f"Could not fetch app {appid} after "
            f"{self.MAX_RETRIES} attempts: {last_error}"
        )

    def apply_batch_result(self, result):
        for appid, info in result.items():
            entry = self.game_cache.setdefault(
                appid,
                {
                    "name": f"Unknown ({appid})",
                    "genres": None,
                    "icon_url": None,
                    "installed": False,
                    "family_shared": False,
                    "fetched": False,
                },
            )

            if info is None:
                # Steam successfully answered but this app has no Store
                # metadata. Mark the lookup as complete. It will not be
                # requested on every startup.
                entry["genres"] = []
                entry["icon_url"] = None
                entry["fetched"] = True
                continue

            genres = []

            for genre in info.get("genres", []):
                if isinstance(genre, dict):
                    name = genre.get("description") or genre.get("name")
                else:
                    name = str(genre)

                if name:
                    name = name.strip()
                    if name and name not in genres:
                        genres.append(name)

            # Keep the name from GetOwnedGames if Store metadata has no name.
            entry["name"] = (
                info.get("name")
                or entry.get("name")
                or f"Unknown ({appid})"
            )
            entry["icon_url"] = info.get("header_image")
            entry["genres"] = genres
            entry["fetched"] = True

            self.all_genres.update(genres)

        self.update_genre_list()

    # ----------------------------
    # Filters / blacklist
    # ----------------------------

    def toggle_installed_only(self):
        self.only_installed = bool(self.installed_var.get())
        self.save_settings()

    def toggle_family_shared(self):
        self.include_family_shared = bool(self.shared_var.get())
        self.save_settings()
        # Shared games are discovered during startup, so explain that a restart
        # is needed after changing this setting.
        self.set_status("Family Shared setting saved. Restart to rescan Steam.")

    def open_blacklist(self):
        window = tk.Toplevel(self.root)
        window.title("Blacklist Games")
        window.geometry("520x600")
        if self.app_icon is not None:
            try:
                window.iconphoto(True, self.app_icon)
            except Exception:
                pass

        ttk.Label(window, text="Blacklist Games", font=("Segoe UI", 14, "bold")).pack(pady=(15,5))
        ttk.Label(window, text="Blacklisted games will never be selected.").pack(pady=(0,10))
        search_var = tk.StringVar()
        ttk.Entry(window, textvariable=search_var).pack(fill="x", padx=15, pady=5)
        frame = ttk.Frame(window); frame.pack(fill="both", expand=True, padx=15, pady=10)
        lb = tk.Listbox(frame, selectmode="multiple", font=("Segoe UI",10))
        sb = ttk.Scrollbar(frame, orient="vertical", command=lb.yview)
        lb.configure(yscrollcommand=sb.set); lb.pack(side="left", fill="both", expand=True); sb.pack(side="right", fill="y")
        ids=[]
        def refresh(*_):
            nonlocal ids
            q=search_var.get().casefold(); lb.delete(0,tk.END); ids=[]
            for g in sorted(self.owned_games, key=lambda x: str(self.game_cache.get(str(x["appid"]),{}).get("name",x.get("name",""))).casefold()):
                aid=str(g["appid"]); name=self.game_cache.get(aid,{}).get("name",g.get("name",aid))
                if q and q not in name.casefold(): continue
                mark="X" if aid in self.blacklist else " "
                shared=" — Family Shared" if self.game_cache.get(aid,{}).get("family_shared") else ""
                lb.insert(tk.END,f"[{mark}] {name}{shared}"); ids.append(aid)
        def add():
            for i in lb.curselection(): self.blacklist.add(ids[i])
            self.save_settings(); refresh()
        def remove():
            for i in lb.curselection(): self.blacklist.discard(ids[i])
            self.save_settings(); refresh()
        buttons=ttk.Frame(window); buttons.pack(fill="x", padx=15, pady=(0,15))
        ttk.Button(buttons,text="Blacklist Selected",command=add).pack(side="left")
        ttk.Button(buttons,text="Remove Selected",command=remove).pack(side="left",padx=6)
        search_var.trace_add("write", refresh); refresh()

    # ----------------------------
    # Game selection
    # ----------------------------

    def pick_game(self):
        selected_indices = self.genre_listbox.curselection()
        selected_genres = [
            self.genre_listbox.get(i)
            for i in selected_indices
        ]

        pool = []

        for game in self.owned_games:
            appid = str(game["appid"])
            playtime = game.get("playtime_forever", 0)
            details = self.game_cache.get(appid, {})

            if appid in self.blacklist:
                continue

            if details.get("family_shared", False) and not self.include_family_shared:
                continue

            if self.only_installed and not details.get("installed", False):
                continue

            # Shared games normally have no playtime in GetOwnedGames. Give
            # them a small base weight instead of excluding them.
            is_shared = bool(details.get("family_shared", False))
            if playtime <= 0 and not is_shared:
                continue

            genres = details.get("genres") or []

            if selected_genres:
                if not any(g in genres for g in selected_genres):
                    continue

            pool.append(game)

        if not pool:
            messagebox.showinfo(
                "No Match",
                "No games found matching your current filters. Try enabling Family Shared games or disabling installed-only mode.",
            )
            return

        weights = [
            max(1, game.get("playtime_forever", 0))
            if game.get("playtime_forever", 0) > 0
            else 60
            for game in pool
        ]

        chosen = random.choices(pool, weights=weights, k=1)[0]
        appid = str(chosen["appid"])
        details = self.game_cache.get(appid, {})

        name = details.get("name") or chosen.get("name") or "Unknown Game"

        self.name_label.config(text=name)
        shared_label = " • Family Shared" if details.get("family_shared", False) else ""
        self.stats_label.config(
            text=(
                f"Playtime: "
                f"{chosen.get('playtime_forever', 0) / 60:.1f} hours"
                f"{shared_label}"
            )
        )

        self.show_icon(details.get("icon_url"))

        webbrowser.open(f"steam://run/{appid}")

    def show_icon(self, url):
        if not url:
            self.icon_label.config(image="", text="🎮")
            return

        try:
            response = requests.get(
                url,
                timeout=self.REQUEST_TIMEOUT,
            )
            response.raise_for_status()

            img_data = Image.open(BytesIO(response.content))
            img_data.thumbnail((250, 125))

            self.photo = ImageTk.PhotoImage(img_data)
            self.icon_label.config(
                image=self.photo,
                text="",
            )

        except Exception:
            self.icon_label.config(
                image="",
                text="🖼️",
            )


if __name__ == "__main__":
    root = tk.Tk()
    app = SteamRandomizerGUI(root)
    root.mainloop()
